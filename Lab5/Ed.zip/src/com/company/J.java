package com.company;

public class J extends I {
    public String j;
}
