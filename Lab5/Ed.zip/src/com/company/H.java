package com.company;

public class H extends G {
    public String h;
}
