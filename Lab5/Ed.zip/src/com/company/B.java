package com.company;

public class B extends A {
    public String b;
}
