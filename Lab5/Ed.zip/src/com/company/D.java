package com.company;

public class D extends C {
    public String d;
}
