package com.company;

public class I extends H {
    public String i;

    public void chooseA() {
        String newEl = new String();

    }
}
