package com.company;

public class C extends B {
    public String c;
}
