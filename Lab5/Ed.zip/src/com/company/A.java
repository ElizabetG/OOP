package com.company;

public class A {
    public String a;
}
