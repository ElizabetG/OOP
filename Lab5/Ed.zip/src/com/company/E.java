package com.company;

public class E extends D {
    public String e;
}
