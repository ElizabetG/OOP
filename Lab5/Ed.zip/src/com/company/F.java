package com.company;

public class F extends E {
    public String f;
}
