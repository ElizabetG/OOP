package com.company;

public class G extends F {
    public String g;
}
